<?php require_once('app/poll.php');?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>PHP Poll Script</title>
  <link rel="icon" href="app/images/favicon.ico">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" href="css/waves.css">
  <link rel="stylesheet" href="css/style-polling.css">
</head>
<body>
<div class="container html5_polling_system">
<p align="right"><a href="http://191.101.50.220/~kristalgroup/app/admin.php" target="_blank"><button class="btn btn-primary">Admin page here</button></a></p>
<h1 class="text-center bottom80px"><?=$pollJson->title;?></h1>
    <div class="row">
        <?=createPollObject('theme1', '1');?>
        <?=createPollObject('theme2', '2');?>
        <?=createPollObject('theme3', '3');?>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Attention</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">...</div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
  <script src="js/jquery-3.5.1.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="js/waves.js"></script>
  <script src="js/polling.js"></script>
    <script type="text/javascript">
        Waves.init();
        Waves.attach('.form-radio_theme1', ['waves-button']);
        Waves.attach('.form-radio_theme2', ['waves-button']);
        Waves.attach('.form-radio_theme3', ['waves-button']);
        Waves.attach('.btn', ['waves-button', 'waves-float', 'waves-light']);
    </script>   
</body>
</html>