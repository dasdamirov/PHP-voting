<?php
function __error($type = null, $value = null){
    echo '<!DOCTYPE html><html><link rel="stylesheet" href="http://191.101.50.220/~aznetwor/codecanyon/polling/css/error.css"><body>';
        switch ($type){
            case 'connection_problem':
                if(isset($value)){
                    $value = $value;
                }else{
                    $value = 'Database error';
                }
                return '<div class="params">
                            <ul>
                                <li class="required">
                                    <div class="key">MySQL:<span class="type">Wrong username or password. Also you may forget write correct server name. It is usually written like this "<b>localhost</b>".</span></div>
                                    <div class="val">'.$value.'</div>
                                </li>
                            </ul>
                        </div>';            
            break;
            
            case 'database_notfound':
                return '<div class="params">
                            <ul>
                                <li class="required">
                                    <div class="key">APP:<span class="type">Database not found.</span></div>
                                    <div class="val">Please install first. Open <b>https://www.yoursite.com/polling/install.php</b> file on your web browser and automatically install it.</div>
                                </li>
                            </ul>
                        </div>';
            break;
            
            case 'file_not_exist':
                return '<div class="params">
                            <ul>
                                <li class="required">
                                    <div class="key">APP:<span class="type">Database file not found.</span></div>
                                    <div class="val">Please install first. Open <b>https://www.yoursite.com/polling/install.php</b> file on your web browser and automatically install it.</div>
                                </li>
                            </ul>
                        </div>';                
                break;
                
           default:
            return null;
        }
    echo '</body></html>';
}