<?php

if(!empty($_POST)){
    print_r($_POST);
    exit();
}

?>
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>

<form method="POST" action="form.php" id="addNewPoll">
  <label for="fname">First name:</label><br>
  <input type="text" id="fname" name="fname[]" value="John"><br><br>
  <label for="lname">Last name:</label><br>
  <input type="text" id="lname" name="fname[]" value="Doe"><br><br>
  <input type="button" value="Submit" id="clck">
</form> 
<div id="result"></div>
<script>
$(document).ready(function(){
    $("#clck").click(function() {
        $.post('form.php', $('#addNewPoll').serialize(), function(response){
            $('#result').html(response);
            $(this).removeAttr('disabled');
        });
    });
    
});
</script>