<?php
/*
*error.php file is catch error data
*/
require_once('error.php');
try {
    if (!@include_once(__DIR__.'/mysql.php'))
        throw new Exception ('mysql.php does not exist');
    if (!file_exists(__DIR__.'/mysql.php'))
        throw new Exception ('mysql.php does not exist');
    else
        require_once(__DIR__.'/mysql.php');
}catch(Exception $e) {    
    echo __error('file_not_exist');
    exit();
}



/*
* Check if table exists function
*/
function tableExists($table) {
    global $conn;
    try {
        $result = $conn->query("SELECT 1 FROM $table LIMIT 1");
    } catch (Exception $e) {
        return FALSE;
    }

    return $result !== FALSE;
}

function miniFilter($variable = null){
    $var = preg_replace("/[^a-zA-Z0-9_@-]+/", "", $variable);
    return $var;                    
}

/*
* Get column from table
*/
function getRow($sql, $parameters){
    global $conn;
    $q = $conn->prepare($sql);
    $q->execute($parameters);
    return $q->fetchColumn();
}



/*
* Get all column from table
*/
function getArray($sql, $parameters){
    global $conn;
    $q = $conn->prepare($sql);
    $q->execute($parameters);
    return $q->fetchAll();
}


function numRows($sql, $parameters){
    global $conn;
    $q = $conn->prepare($sql);
    $q->execute($parameters);
    return $q->fetchColumn();
}



/*
* Get main configuration from database and convert json type for simple using
*/
$pollSettings = getRow("SELECT config_settings FROM poll_configs WHERE id=?", ['1']);
$pollJson = json_decode($pollSettings);



/*
* Check if main configs table exists or not
*/
if(tableExists('poll_configs') !== FALSE){
        
}else{
    echo __error('database_notfound');
    exit();
}


/*
* Get total result per poll
*/
function getResultPoll($post){
    global $conn;
    $post = miniFilter($post);
    $htm = null;
    $num = numRows('SELECT COUNT(*) FROM poll_tracking WHERE question_id=? AND user_ip=?', [$post, $_SERVER['REMOTE_ADDR']]);
    $countTotalPollAnswer = numRows('SELECT COUNT(*) FROM poll_tracking WHERE question_id=?', [$post]);

    $htm .= '<script>document.querySelectorAll("span.result-percentage_'.$post.'").forEach(function(e,t){var n=e.getAttribute("style");n=(n=n.replace("width:","")).substr(0,n.length-1);var l=parseInt(n),r=0,a=setInterval(function(){r++,e.nextElementSibling.innerHTML=r+"%",r===l&&clearInterval(a),0===l&&(e.nextElementSibling.style.color="black",clearInterval(a),e.nextElementSibling.innerHTML="0%")},1e3/(l+1))});</script>';

        foreach(getArray("SELECT id, answer FROM poll_answers WHERE question_id=?", [$post]) as $row){
            $countPollAnswer = numRows('SELECT COUNT(*) FROM poll_tracking WHERE question_id=? AND answer_id=?', [$post, $row['id']]);
            
            if($countTotalPollAnswer > 0){
                 $percent = ($countPollAnswer*100)/$countTotalPollAnswer;
            }else{
                 $percent = '0';
            }
            $htm .= $row['answer'].'<div class="meter">
                      <span class="result-percentage_'.$post.'" style="width:'.$percent.'%"></span>
                      <p></p>
                    </div>';
        }
        
        echo $htm;
}



if(@$_GET['send'] == 'request' && isset($_POST['opt']) && isset($_POST['que'])){
    $htm = null;
    $num = numRows('SELECT COUNT(*) FROM poll_tracking WHERE question_id=? AND user_ip=?', [miniFilter($_POST['que']), $_SERVER['REMOTE_ADDR']]);
    $countTotalPollAnswer = numRows('SELECT COUNT(*) FROM poll_tracking WHERE question_id=?', [miniFilter($_POST['que'])]);
    
    $foundID = numRows('SELECT COUNT(*) FROM poll_questions WHERE id=?', [miniFilter($_POST['que'])]);
    
    if($foundID > 0){
            
            if($num == 0){
            $data = [
                'question_id' => miniFilter($_POST['que']),
                'answer_id' => miniFilter($_POST['opt']),
                'user_ip' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'],
                'created_at' => time()
            ];
            
            $sql = "INSERT INTO poll_tracking (question_id, answer_id, user_ip, user_agent, created_at) VALUES (:question_id, :answer_id, :user_ip, :user_agent, :created_at)";
            $insert= $conn->prepare($sql);
            $insert->execute($data);
                                
        }
        
        echo getResultPoll(miniFilter($_POST['que']));
        exit();
    }
    
}





if(@$_GET['send'] == 'showResult' && isset($_POST['que'])){
    echo getResultPoll(miniFilter($_POST['que']));
    exit();    
}




/*
* Create poll form
*/
function createPollObject($themeName, $selectedQuestionId){
    global $conn;
    global $pollJson;
        $i = 0;

    if($themeName == 'theme2'){
        $themeName = $pollJson->theme2->theme_name;
        $question = getRow("SELECT question FROM poll_questions WHERE show_status='1' and id=?", [$selectedQuestionId]);
        
        if($question){
            
            $html = '<div class="col-md-4 top10px"><div class="poll_line">
                        <div class="p-3 mb-3 swatch-indigo">'.$themeName.'</div>
                        <div class="p-3 mb-3 polling-theme2">
                            <legend class="bottom20px polling_default_values">'.$question.'</legend>
                            <div class="poling-action_'.$selectedQuestionId.'">';
                        
                        foreach(getArray("SELECT id, answer FROM poll_answers WHERE question_id=?", [$selectedQuestionId]) as $row){
                            $i++;
                            $html .= '<input type="radio" name="polling_'.$selectedQuestionId.'" id="radio_'.$row['id'].'" value="'.$row['id'].'">
                                        <label class="form-radio_theme2 form-check-label" for="radio_'.$row['id'].'">
                                         '.$row['answer'].'
                                      </label>';
                        }
            
            $html .= '</div><div class="poling-result_'.$selectedQuestionId.'"></div>
                        <div class="text-right top10px">
                            <button type="button" id="'.$selectedQuestionId.'" class="vote btn btn-custom2">Vote</button>
                            <button type="button" id="poll_result_'.$selectedQuestionId.'" class="pollResult btn btn-success">View Result</button>
                            <button type="button" class="p_back btn btn-success">Back</button>
                        </div>
                        </div>
                    </div>
                </div>';
        }        
    }elseif($themeName == 'theme3'){
        $themeName = $pollJson->theme3->theme_name;
        $question = getRow("SELECT question FROM poll_questions WHERE show_status='1' and id=?", [$selectedQuestionId]);
        
        if($question){
            $html = '<div class="col-md-4 top10px"><div class="poll_line">
                        <div class="p-3 mb-3 swatch-purple">'.$themeName.'</div>
                        <div class="p-3 mb-3 polling-theme3">
                            <legend class="bottom20px polling_default_values">'.$question.'</legend>
                            <div class="poling-action_'.$selectedQuestionId.'">';
                        
                        foreach(getArray("SELECT id, answer FROM poll_answers WHERE question_id=?", [$selectedQuestionId]) as $row){
                            $i++;
                            $html .= '<input type="radio" name="polling_'.$selectedQuestionId.'" id="radio_'.$row['id'].'" value="'.$row['id'].'">
                                        <label class="form-radio_theme3 form-check-label" for="radio_'.$row['id'].'">
                                         '.$row['answer'].'
                                      </label>';
                        }
            
            $html .= '</div><div class="poling-result_'.$selectedQuestionId.'"></div>
                        <div class="text-right top10px">
                            <button type="button" id="'.$selectedQuestionId.'" class="vote btn btn-custom3">Vote</button>
                            <button type="button" id="poll_result_'.$selectedQuestionId.'" class="pollResult btn btn-success">View Result</button>
                            <button type="button" class="p_back btn btn-success">Back</button>
                        </div>
                        </div>
                    </div>
                </div>';
                
        }        
    }elseif('theme1'){
        $themeName = $pollJson->theme1->theme_name;
        $question = getRow("SELECT question FROM poll_questions WHERE show_status='1' and id=?", [$selectedQuestionId]);
        
        if($question){
            $html = '<div class="col-md-4 top10px"><div class="poll_line">
                        <div class="p-3 mb-3 swatch-blue">'.$themeName.'</div>
                        <div class="p-3 mb-3 polling-theme1">
                            <legend class="bottom20px polling_default_values">'.$question.'</legend>
                            <div class="poling-action_'.$selectedQuestionId.'">';
                        
                        foreach(getArray("SELECT id, answer FROM poll_answers WHERE question_id=?", [$selectedQuestionId]) as $row){
                            $i++;
                            $html .= '<label class="form-radio_theme1 form-check-label" for="radio_'.$row['id'].'">
                                        <input type="radio" name="polling_'.$selectedQuestionId.'" id="radio_'.$row['id'].'" value="'.$row['id'].'">
                                         '.$row['answer'].'
                                      </label>';
                        }
            
            $html .= '</div><div class="poling-result_'.$selectedQuestionId.'"></div>
                        <div class="text-right top10px">
                            <button type="button" id="'.$selectedQuestionId.'" class="vote btn btn-primary">Vote</button>
                            <button type="button" id="poll_result_'.$selectedQuestionId.'" class="pollResult btn btn-success">View Result</button>
                            <button type="button" class="p_back btn btn-success">Back</button>
                        </div>
                        </div>
                    </div>
                </div>';
        }
    }
    
    

        
        return @$html;
  
}