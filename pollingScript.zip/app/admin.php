<?php
/*
*admin.php file 
*/
session_start();
ob_start();
//session_destroy();
require_once('error.php');

//echo md5(md5('admin'));

try {
    if (!@include_once(__DIR__.'/mysql.php'))
        throw new Exception ('mysql.php does not exist');
    if (!file_exists(__DIR__.'/mysql.php'))
        throw new Exception ('mysql.php does not exist');
    else
        require_once(__DIR__.'/mysql.php');
}catch(Exception $e) {    
    echo __error('file_not_exist');
    exit();
}

/*
*getRow function
*/
function getRow($sql = null, $parameters = null, $all = null){
    global $conn;
    $q = $conn->prepare($sql);
    $q->execute($parameters);
    
    if($all != null){
        return $q->fetchAll(PDO::FETCH_ASSOC);
    }else{
        return $q->fetchColumn();
    }
}


/*
*getCount function
*/
function getCount($table = null){
    global $conn;
    
    if($table != null){
        $sql = "SELECT COUNT(*) FROM ".$table;
        $res = $conn->query($sql);
        $count = $res->fetchColumn();
        return $count;
    }else{
        return 0;    
    }
    
}
 
/*
*getCount function
*/
function getCountFromUserForm($table = null, $parameters){
    global $conn;
    if($table != null){
        $sql = "SELECT COUNT(*) FROM ".$table;
        $q = $conn->prepare($sql);
        $q->execute($parameters);
        $count = $q->fetchColumn();
        return $count;
    }else{
        return 0;    
    }
    
}   
    

/*
*Logout function
*/
if(isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token']) && !empty($_GET['logout'])){
    if($_GET['logout'] == $_SESSION['session_access_token']){
        session_destroy();
        header('location: admin.php');
    }else{
        echo 'Hacking attempt!';
        exit();
    }
}

/*
*Login function
*/
if(!empty($_POST['uname']) && !empty($_POST['passwd'])){

    $pollSettings = getRow("SELECT config_settings FROM poll_configs WHERE id=?", ['1']);
    $pollJson = json_decode($pollSettings);
    
    if($_POST['uname'] == $pollJson->adm_uname && md5(md5($_POST['passwd'])) == $pollJson->adm_passwd){
        $value = array("user"=>"success");
        echo json_encode($value);
        $_SESSION["admin_poll"] = $pollJson->adm_uname;
        $_SESSION["session_access_token"] = bin2hex(openssl_random_pseudo_bytes(16));
    }else{
        $value = array("user"=>"not_exist");
        echo json_encode($value);
    }
    
    exit();
}


/*
*Filter post function
*/
function miniFilter($variable = null){
    $var = preg_replace("/[^a-zA-Z0-9_@-]+/", "", $variable);
    return $var;                    
}




/*
*Change password function
*/
if(!empty($_GET['page']) && $_GET['page'] == 'changePassword' && isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token'])){
    if(!empty($_POST['userPassword']) && !empty($_POST['userName'])){
        $pollSettings = getRow("SELECT config_settings FROM poll_configs WHERE id=?", ['1']);
        $pollJson = json_decode($pollSettings, true);

        $pollJson["adm_passwd"] = md5(md5(miniFilter($_POST['userPassword'])));
        $pollJson["adm_uname"] = miniFilter($_POST['userName']);
        
        $pollJson = json_encode($pollJson);
        $sql = "UPDATE poll_configs SET config_settings = '$pollJson' WHERE id = 1";
        $update= $conn->prepare($sql);
        $update->execute();
        $value = array("password"=>"success");
        echo json_encode($value);
    }else{
        $value = array("password"=>"fail");
        echo json_encode($value);
    }
    session_destroy();
    exit();
}



/*
*Add new Poll function
*/
if(!empty($_GET['page']) && $_GET['page'] == 'addPoll' && isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token'])){
    
    if(!empty($_POST['p_question']) && !empty($_POST['poll_options'])){
        $data = [
            'question' => $_POST['p_question'],
            'created_at' => time(),
            'updated_at' => time(),
            'show_status' => 1
        ];
        
        $sql = "INSERT INTO poll_questions (question, created_at, updated_at, show_status) VALUES (:question, :created_at, :updated_at, :show_status)";
        $insert= $conn->prepare($sql);
        $insert->execute($data);  
        
        $pollID = $conn->lastInsertId();
        
        foreach ($_POST['poll_options'] as $row){
            $data = [
                'question_id' =>$pollID,
                'answer' => $row,
                'show_status' => 1
            ];
            
            $sql = "INSERT INTO poll_answers (question_id, answer, show_status) VALUES (:question_id, :answer, :show_status)";
            $insert= $conn->prepare($sql);
            $insert->execute($data);              
        }
        
        if($pollID){
            $value = array("added"=>"success");
            echo json_encode($value);
        }else{
            $value = array("added"=>"fail");
            echo json_encode($value);            
        }
        
    }
    
    exit();  
}




/*
*Edit Poll function
*/
if(!empty($_GET['page']) && $_GET['page'] == 'editPoll' && isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token'])){
    
    if(!empty($_POST['editPollQuestion']) && !empty($_POST['poll_options'])){
        
        $data = [
            'id' => $_POST['updatePollID'],
            'question' => $_POST['editPollQuestion'],
            'updated_at' => time(),
            'show_status' => (!empty($_POST['status'])) ? 1:0
        ];
        
        $sql = "UPDATE poll_questions SET question=:question, updated_at=:updated_at, show_status=:show_status WHERE id =:id";
        $update = $conn->prepare($sql);
        $update->execute($data);  
        
        if(!empty($_POST['status']) && $_POST['status'] == 'on'){
            $status = 1;        
        }else{
            $status = 0;
        }
        
        if(!empty($_POST['newOption'])){
            $sql = "INSERT INTO poll_answers (question_id, answer, show_status) VALUES (:question_id, :answer, :show_status)";
            $insert= $conn->prepare($sql);
            foreach($_POST['newOption'] as $value){
                $insert->execute([
                    'question_id' => $_POST['updatePollID'],
                    'answer' => $value,
                    'show_status' => $status
                ]); 
            }
        }
        
        
        $sqlOption = "UPDATE poll_answers SET answer=:optVal, show_status=:show_status WHERE id=:optID";
        $up = $conn->prepare($sqlOption);     

        for ($i=0;$i<count($_POST['optionId']);$i++){

            $up->execute([
                'optID' => $_POST['optionId'][$i],
                'optVal' => $_POST['poll_options'][$i],
                'show_status' => $status
            ]);    
            
        }
        
        $count = $update->rowCount();
        
        if($count){
            $value = array("edited"=>"success");
            echo json_encode($value);
        }else{
            $value = array("edited"=>"fail");
            echo json_encode($value);            
        }
        
        
    }
    
    exit();  
}





/*
*Delete Poll function
*/
if(!empty($_GET['page']) && $_GET['page'] == 'deletePoll' && isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token'])){

    if(!empty($_POST['delete'])){

        $poll = [
            'question_id' =>$_POST['delete']
            ];
        $sql = "DELETE FROM poll_questions WHERE id=:question_id";
        $delete = $conn->prepare($sql);
        $delete->execute($poll);   


        $answer = [
            'question_id' =>$_POST['delete']
            ];
        $sql = "DELETE FROM poll_answers WHERE question_id=:question_id";
        $delete = $conn->prepare($sql);
        $delete->execute($answer);
        

        $tracking = [
            'question_id' =>$_POST['delete']
            ];
        $sql = "DELETE FROM poll_tracking WHERE question_id=:question_id";
        $delete = $conn->prepare($sql);
        $delete->execute($tracking);

    
        if($delete){
            $value = array("deleted"=>"success");
            echo json_encode($value);
        }else{
            $value = array("deleted"=>"fail");
            echo json_encode($value);            
        }        
    }

    exit();
}





/*
*Delete Poll options
*/
if(!empty($_GET['page']) && $_GET['page'] == 'removeOption' && isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token'])){

    if(!empty($_POST['rm'])){

        $answer = [
            'option_id' =>$_POST['rm']
            ];
        $sql = "DELETE FROM poll_answers WHERE id=:option_id";
        $delete = $conn->prepare($sql);
        $delete->execute($answer);
        

        $tracking = [
            'option_id' =>$_POST['rm']
            ];
        $sql = "DELETE FROM poll_tracking WHERE answer_id=:option_id";
        $delete = $conn->prepare($sql);
        $delete->execute($tracking);

    
        if($delete){
            $value = array("deleted"=>"success");
            echo json_encode($value);
        }else{
            $value = array("deleted"=>"fail");
            echo json_encode($value);            
        }        
    }

    exit();
}





/*
*Generate edit Poll form
*/
if(!empty($_GET['page']) && $_GET['page'] == 'getEdit' && isset($_SESSION['admin_poll']) && isset($_SESSION['session_access_token'])){
    
    if(!empty($_POST['editPollId'])){
        
        $_POLL = getRow("SELECT * FROM poll_questions WHERE id=?", [$_POST['editPollId']], 'all');

            if(!$_POLL[0]['id']){
                $value = array("pollExists"=>"fail");
                echo json_encode($value);                  
            }else{
                
                
            if($_POLL[0]['show_status'] == 1){
                $sts = "checked";
            }else{
                $sts = null;
            }
                    
            $answer = [
                'question_id' =>$_POLL[0]['id']
            ];
                
                $sql = "SELECT * FROM poll_answers WHERE question_id = :question_id ORDER by id DESC";
                $q = $conn->prepare($sql);
                $q->execute($answer);
                $result = $q->fetchAll();
                
                
                $script = '<script>
                    $(document).ready(function(){
                    
                        $(".remove").click(function() {
                            
                            var parentRmButton = $(this).parent().parent();
                                removeID = parentRmButton.attr("id");
                            var confirmation = confirm("Your selected option will be deleted. Are you sure?");
                            if (confirmation == true) {
                                if(removeID.length !== 0){
                                    $(this).attr("disabled", "disabled");
                                        $.post("admin.php?page=removeOption", {rm:removeID}, function(response){
                                            if(response.deleted == "success"){
                                                parentRmButton.remove();                                
                                            }
                                            $(this).removeAttr("disabled");
                                        }.bind(this), "json");
                                        
                                }
                            }
                        });
                        
                        $("#addEdit").click(function() {
                            var lastField = $("#editOptionsArea div:last-child");
                            var intId = (lastField && lastField.length && lastField.data("id") + 1) || 1;
                            var fieldWrapper = $("<div class=\"input-group mb-3\" id=\"" + intId + "\"/>");
                                fieldWrapper.data("id", intId);
                            var fName = $("<input type=\"text\" class=\"form-control\" name=\"newOption[]\" placeholder=\"Poll options\" aria-describedby=\"button-addon4\">");
                            var removeButton = $("<a class=\"input-group-append\" id=\"button-addon4\"><button class=\"btn btn-danger remove\" type=\"button\">Delete field</button></a>");
                            
                                removeButton.click(function() {
                                    $(this).parent().remove();
                                });
                                
                                fieldWrapper.append(fName);
                                fieldWrapper.append(removeButton);
                                $("#editOptionsArea").append(fieldWrapper);
                        });
                        
                        $("#editPollButton").click(function() {
                        var editQuestion = $("#editPollQuestion").val().length;
                            if(editQuestion !== 0){
                                $(this).attr("disabled", "disabled");
            
                                    $.post("admin.php?page=editPoll", $("#editPollFormSerialize").serialize(), function(response){
                                        if(response.edited == "success"){
                                            alert("Thank you, your poll successfully edited.");
                                            $("#editModal").modal("hide");
                                            location.reload(true);
                                        }else{
                                            alert("Poll edited failed.");
                                        }
                                        $(this).removeAttr("disabled");
                                    }.bind(this), "json");
                            }                
                
                        });
                        
                        
                    });
                </script>';
                $options = '<form action="admin.php?page=editPoll" method="POST" id="editPollFormSerialize">
                                <div class="modal-body">
                                    <div class="input-group mb-3">
                                      <div class="input-group-prepend">
                                        <span class="input-group-text" id="inputGroup-sizing-default">Poll question</span>
                                      </div>
                                      <input type="hidden" id="updatePollID" name="updatePollID" value="'.$_POLL[0]['id'].'">
                                      <input type="text" class="form-control pollQuestionInput" name="editPollQuestion" value="'.$_POLL[0]['question'].'" id="editPollQuestion" aria-describedby="inputGroup-sizing-default">
                                    </div>
                                    <div id="editOptionsArea">';
                                    
                                    foreach($result as $row) {
                                         $options .= '<div class="input-group mb-3" id="'.$row['id'].'"><input type="hidden" name="optionId[]" value="'.$row['id'].'"><input type="text" class="form-control newPollOption" data-id="'.$row['id'].'" name="poll_options[]" aria-describedby="button-addon4" value="'.$row['answer'].'" required><a class="input-group-append"><button class="btn btn-danger remove" type="button">Delete field</button></a></div>';
                                    }
                
                $options .= '       </div>
                            <div class="form-check form-switch float-right">
                                      <input class="form-check-input" type="checkbox" id="pollStatusCheck" name="status"'.$sts.'>
                                      <label class="form-check-label" for="pollStatusCheck">Active</label>
                                    </div>
            
                                    <div>
                                        <a class="btn btn-sm btn-labeled btn-primary" id="addEdit">
                                          <span class="btn-label">
                                            <span class="oi oi-plus" aria-hidden="true" style="color:#fff;"></span>
                                          </span>
                                          <span class="btn-text" style="color:#fff;">
                                            Add a field
                                          </span>
                                        </a>
                                    </div>
                                </div>
                                
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                  <button type="button" class="btn btn-primary" id="editPollButton">Save</button>
                                </div>
                            </form>';
          
                
                    $value = array(
                        "pollExists" => "success", 
                        "html" => $options,
                        "script" => $script
                    );
                    echo json_encode($value);      
            }
                    
    }else{
            $value = array("pollExists"=>"fail");
            echo json_encode($value);            
    }

    exit();
}    





if(isset($_SESSION['admin_poll'])){
    $go = miniFilter(@$_GET['page']);

        if(empty($go)){
            $breadcrumb = 'Dashboard';
        }elseif($go == 'polls'){
            $breadcrumb = 'Poll options';
        }elseif($go == 'embed'){
            $breadcrumb = 'Embed code';
        }elseif($go == 'settings'){
            $breadcrumb = 'Settings';
        }elseif($go == 'user'){
            $breadcrumb = 'Edit user';
        }else{
            $breadcrumb = '';
        } 
    
    
    function getPolls(){
        global $conn;
        $sql = "SELECT * FROM poll_questions ORDER by id DESC";
        $res = $conn->query($sql);
        $result = $res->fetchAll();
        foreach($result as $row) {
            
            if($row['show_status'] == 1){
                $status = 'Active';
            }else{
                $status = 'Inactive';
            }
            
            echo '<tr>
                    <th scope="row">
                        <label class="custom-control custom-checkbox m-0 p-0">
                          <input type="checkbox" class="custom-control-input table-select-row">
                          <span class="custom-control-indicator"></span>
                        </label>
                      </th>
                      <td class="pollId">'.$row['id'].'</td>
                      <td class="pollQuestion">'.$row['question'].'</td>
                      <td>'.date("d F Y H:i:s", $row['created_at']).'</td>
                      <td>'.date("d F Y H:i:s", $row['updated_at']).'</td>
                      <td>'.$status.'</td>
                      <td>
                        <a href="#" class="btn btn-sm btn-labeled btn-primary editPoll" data-id="'.$row['id'].'" data-bs-toggle="modal" data-bs-target="#editModal">
                          <span class="btn-label">
                            <span class="oi oi-pencil" aria-hidden="true"></span>
                          </span>
                          <span class="btn-text">
                            Edit
                          </span>
                        </a> 
                        <a href="#" id="'.$row['id'].'" class="btn btn-sm btn-labeled btn-danger deletePoll" data-id="'.$row['id'].'">
                          <span class="btn-label">
                            <span class="oi oi-trash" aria-hidden="true"></span>
                          </span>
                          <span class="btn-text">
                            Delete
                          </span>
                        </a> 
                      </td>
                    </tr>';
                        
        }        
    }
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Admin Poll</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="icon" href="images/favicon.ico">
    <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="dist/css/admin.css" media="screen" />
  </head>
  <body>
    <div class="adminx-container">
      <nav class="navbar navbar-expand justify-content-between fixed-top">
        <a class="navbar-brand mb-0 h1 d-none d-md-block" href="admin.php">
          <img src="images/logo.png" class="navbar-brand-image d-inline-block align-top mr-2" alt="">
          Poll Admin
        </a>

        <div class="d-flex flex-1 d-block d-md-none">
          <a href="#" class="sidebar-toggle ml-3">
            <i data-feather="menu"></i>
          </a>
        </div>

        <ul class="navbar-nav d-flex justify-content-end mr-2">
          <li class="nav-item dropdown">
            <a class="nav-link avatar-with-name" id="navbarDropdownMenuLink" data-bs-toggle="dropdown" href="#">
              <img src="images/privacy-icon.png" class="d-inline-block align-top" alt="">
            </a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
              <a class="dropdown-item" href="?page=user">Edit user</a>
              <a class="dropdown-item" href="?page=settings">Settings</a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item text-danger" href="?logout=<?=miniFilter($_SESSION['session_access_token']);?>">Sign out</a>
            </div>
          </li>
        </ul>
        
      </nav>

      <!-- expand-hover push -->
      <!-- Sidebar -->
      <div class="adminx-sidebar expand-hover push" id="sidebar">
        <ul class="sidebar-nav">
            
          <li class="sidebar-nav-item">
            <a href="admin.php" class="sidebar-nav-link<?=empty($go) ? ' active' : '';?>">
              <span class="sidebar-nav-icon">
                <i data-feather="home"></i>
              </span>
              <span class="sidebar-nav-name">
                Dashboard
              </span>
            </a>
          </li>

          <li class="sidebar-nav-item">
            <a href="?page=polls" class="sidebar-nav-link<?=($go === 'polls') ? ' active' : '';?>">
              <span class="sidebar-nav-icon">
                <i data-feather="edit"></i>
              </span>
              <span class="sidebar-nav-name">
                Poll options
              </span>
            </a>
          </li>
          
          <li class="sidebar-nav-item">
            <a href="?page=embed" class="sidebar-nav-link<?=($go === 'embed') ? ' active' : '';?>">
              <span class="sidebar-nav-icon">
                <i data-feather="copy"></i>
              </span>
              <span class="sidebar-nav-name">
                Embed code
              </span>
            </a>
          </li>

          <li class="sidebar-nav-item">
            <a href="?page=settings" class="sidebar-nav-link<?=($go === 'settings') ? ' active' : '';?>">
              <span class="sidebar-nav-icon">
                <i data-feather="settings"></i>
              </span>
              <span class="sidebar-nav-name">
                Settings
              </span>
            </a>
          </li>
          
        </ul>
      </div>
      <!-- Sidebar End -->

      <div class="adminx-content">

        <div class="adminx-main-content">
          <div class="container-fluid">
            <!-- BreadCrumb -->
            <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='currentColor'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
              <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?=$breadcrumb;?></li>
              </ol>
            </nav>            
            
            <div class="pb-3">
              <h1><?=$breadcrumb;?></h1>
            </div>
            
            <?php if($go == null){ ?>
            
            <div class="row">
              <div class="col-md-6 col-lg-3 d-flex">
                <div class="card mb-grid w-100">
                  <div class="card-body d-flex flex-column">
                    <div class="d-flex justify-content-between mb-3">
                      <h5 class="card-title mb-0">
                        Votes (Daily)
                      </h5>

                      <div class="card-title-sub">
                        <?=getCount('poll_tracking WHERE created_at >= '.strtotime("-24 hours"));?>
                      </div>
                    </div>

                    <div class="progress mt-auto">
                        
                        <?php 
                        
                            if(getCount('poll_tracking WHERE created_at >= '.strtotime("-1 week")) != 0){
                                $cnd = getCount('poll_tracking WHERE created_at >= '.strtotime("-1 week"));
                                $vnd = getCount('poll_tracking WHERE created_at >= '.strtotime("-24 hours"));
                            }else{
                                $cnd = 1; 
                                $vnd = 0;
                            }
                            
                            $vold = (getCount('poll_tracking WHERE created_at >= '.strtotime("-24 hours"))*100)/$cnd;

                        ?>
                        
                      <div class="progress-bar" role="progressbar" style="width: <?=$vold;?>%;" aria-valuenow="<?=$vold;?>" aria-valuemin="0" aria-valuemax="100"><?=$vnd;?></div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6 col-lg-3 d-flex">
                <div class="card mb-grid w-100">
                  <div class="card-body d-flex flex-column">
                    <div class="d-flex justify-content-between mb-3">
                      <h5 class="card-title mb-0">
                        Votes (Weekly)
                      </h5>

                      <div class="card-title-sub">
                        <?=getCount('poll_tracking WHERE created_at >= '.strtotime("-1 week"));?>
                      </div>
                    </div>

                    <div class="progress mt-auto">
                        
                        <?php 
                        
                            if(getCount('poll_tracking WHERE created_at >= '.strtotime("-2 week")) != 0){
                                $cnw = getCount('poll_tracking WHERE created_at >= '.strtotime("-2 week"));
                                $vnw = getCount('poll_tracking WHERE created_at >= '.strtotime("-1 week"));
                            }else{
                                $cnw = 1; 
                                $vnw = 0;
                            }
                            
                            $volw = (getCount('poll_tracking WHERE created_at >= '.strtotime("-1 week"))*100)/$cnw;

                        ?>                        
                      <div class="progress-bar" role="progressbar" style="width: <?=$volw;?>%;" aria-valuenow="<?=$volw;?>" aria-valuemin="0" aria-valuemax="100"><?=$vnw;?></div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6 col-lg-3 d-flex">
                <div class="card border-0 bg-primary text-white text-center mb-grid w-100">
                  <div class="d-flex flex-row align-items-center h-100">
                    <div class="card-icon d-flex align-items-center h-100 justify-content-center">
                      <i data-feather="list"></i>
                    </div>
                    <div class="card-body">
                      <div class="card-info-title">Total polls</div>
                      <h3 class="card-title mb-0">
                        <?=getCount('poll_questions');?>
                      </h3>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6 col-lg-3 d-flex">
                <div class="card border-0 bg-success text-white text-center mb-grid w-100">
                  <div class="d-flex flex-row align-items-center h-100">
                    <div class="card-icon d-flex align-items-center h-100 justify-content-center">
                      <i data-feather="users"></i>
                    </div>
                    <div class="card-body">
                      <div class="card-info-title">Total votes</div>
                      <h3 class="card-title mb-0">
                        <?=number_format(getCount('poll_tracking'));?>
                      </h3>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <?php }elseif($go == 'user'){ ?>
            
            <div class="row">
              <div class="col">
                <div class="card mb-grid">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <div class="card-header-title">Users</div>
                  </div>
                  <div class="table-responsive-md">
                    <table class="table table-actions table-striped table-hover mb-0">
                      <thead>
                        <tr>
                          <th scope="col">
                            <label class="custom-control custom-checkbox m-0 p-0">
                              <input type="checkbox" class="custom-control-input table-select-all">
                              <span class="custom-control-indicator"></span>
                            </label>
                          </th>
                          <th scope="col">Username</th>
                          <th scope="col">Role</th>
                          <th scope="col">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">
                            <label class="custom-control custom-checkbox m-0 p-0">
                              <input type="checkbox" class="custom-control-input table-select-row">
                              <span class="custom-control-indicator"></span>
                            </label>
                          </th>
                          <td><?=miniFilter($_SESSION['admin_poll']);?></td>
                          <td>
                            <span class="badge badge-pill badge-primary">Admin</span>
                          </td>
                          <td>
                            <a href="#" class="btn btn-sm btn-labeled btn-primary" id="userBtn" data-bs-toggle="modal" data-bs-target="#userModal">
                              <span class="btn-label">
                                <span class="oi oi-pencil" aria-hidden="true"></span>
                              </span>
                              <span class="btn-text">
                                Edit
                              </span>
                            </a> 
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            
          <!-- Modal -->
          <div class="modal fade" id="userModal" role="dialog" data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-lg">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Edit user</h4>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                
                <div class="modal-body">
                    
                <form id="changePassword">
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default">Username</span>
                      </div>
                      <input type="text" class="form-control" name="userName" aria-describedby="inputGroup-sizing-default" value="<?=miniFilter($_SESSION['admin_poll']);?>">
                    </div>
                    
                    <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text" id="inputGroup-sizing-default userInputPassword">Password&nbsp;</span>
                      </div>
                      <input type="password" class="form-control" name="userPassword" id="userInputPassword" aria-describedby="inputGroup-sizing-default">
                    </div>
                    If you want to change your username and password, enter your new username and new password then click <b>Save</b> button.
                </form>
                
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary" id="userEditSave">Save</button>
                </div>
              </div>
            </div>
          </div>
          
          
            <?php }elseif($go == 'polls'){ ?>
            
            <div class="row">
              <div class="col">
                <div class="card mb-grid">
                  <div class="card-header d-flex justify-content-between align-items-center">
                    <div class="card-header-title">Polls</div>
                    
                        <a href="#" class="btn btn-sm btn-labeled btn-primary" id="pollBtn" data-bs-toggle="modal" data-bs-target="#pollModal">
                          <span class="btn-label">
                            <span class="oi oi-plus" aria-hidden="true"></span>
                          </span>
                          <span class="btn-text">
                            Add new
                          </span>
                        </a>

                  </div>
                  <div class="table-responsive-md">
                    <table class="table table-actions table-striped table-hover mb-0">
                      <thead>
                        <tr>
                          <th scope="col">
                            <label class="custom-control custom-checkbox m-0 p-0">
                              <input type="checkbox" class="custom-control-input table-select-all">
                              <span class="custom-control-indicator"></span>
                            </label>
                          </th>
                          <th scope="col">ID</th>
                          <th scope="col">Question</th>
                          <th scope="col">Created</th>
                          <th scope="col">Updated</th>
                          <th scope="col">Status</th>
                          <th scope="col">Action</th>
                        </tr>
                      </thead>
                      <tbody>
                          
                        <?=getPolls();?>
                        
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>  



          <!-- Modal -->
          <div class="modal fade" id="editModal" role="dialog" data-bs-backdrop="static" data-bs-keyboard="false">
            <div class="modal-dialog modal-lg">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Edit poll</h4>
                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div id="editContent"></div>
              </div>
            </div>
          </div>



          <!-- Modal -->
          <div class="modal fade" id="pollModal" role="dialog" data-backdrop="static" data-keyboard="false">
            <div class="modal-dialog modal-lg">
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title">Add new poll</h4>
                  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    
                    <form id="addNewPoll">
                        <div class="input-group mb-3">
                          <div class="input-group-prepend">
                            <span class="input-group-text" id="inputGroup-sizing-default">Poll question</span>
                          </div>
                          <input type="text" class="form-control" name="p_question" id="p_question" aria-describedby="inputGroup-sizing-default">
                        </div>
                        <fieldset id="optionsArea"></fieldset>
                        <div>
                            <a class="btn btn-sm btn-labeled btn-primary" id="add">
                              <span class="btn-label">
                                <span class="oi oi-plus" aria-hidden="true" style="color:#fff;"></span>
                              </span>
                              <span class="btn-text" style="color:#fff;">
                                Add a field
                              </span>
                            </a>
                        </div>
                    </form>
                    
                
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                  <button type="button" class="btn btn-primary" id="addNew">Save</button>
                </div>
              </div>
            </div>
          </div>
          
            <script>
                $(document).ready(function(){
                    $("#add").click(function() {
                        var lastField = $("#optionsArea div:last-child");
                        var intId = (lastField && lastField.length && lastField.data("id") + 1) || 1;
                        var fieldWrapper = $("<div class=\"input-group mb-3\" id=\"" + intId + "\"/>");
                            fieldWrapper.data("id", intId);
                        var fName = $("<input type=\"text\" class=\"form-control newPollOption\" name=\"poll_options[]\" placeholder=\"Poll options\" aria-describedby=\"button-addon4\">");
                        var removeButton = $("<a class=\"input-group-append\"><button class=\"btn btn-danger remove\" type=\"button\">Delete field</button></a>");
                        
                            removeButton.click(function() {
                                $(this).parent().remove();
                            });
                            
                            fieldWrapper.append(fName);
                            fieldWrapper.append(removeButton);
                            $("#optionsArea").append(fieldWrapper);
                    }); 
                });
            </script>


          <?php  }elseif($go == 'embed'){ ?>
          
          <div class="row">
              <div class="col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <div class="card-header-title">Integration</div>
                  </div>
                  <div class="card-body">
                    <p>If you want to integrate poll script to your site you must follow the instructions below.</p>
                    <ul>
                        <li>First upload <b>PHP, jQuery & Bootstrap Poll Script</b> script <b>zip</b> file to your host and extract it any directory.</li>
                        <li>Then go to installation file on your browser (<b>https://www.yoursite.com/polling/install.php</b>) and install script to your host.</li>
                        <li>If installation can't automatically create <b>/app/mysql.php</b> file, you have to create it manually and write code below into it.</b></li>
                        <li style="list-style:none;margin-top:15px;margin-bottom:15px;">
                                <div class="CodeMirror cm-s-hopscotch" id="c_mysql"><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 29px; margin-bottom: -15px; border-right-width: 15px; min-height: 278px; min-width: 672.359px;padding-top: 15px; padding-right: 15px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div style="text-align:right;"><button class="btn btn-sm btn-dark copy-text1" data-clipboard-target="#c_mysql">Copy</button></div><div role="presentation" style="position: relative; outline: none;"><div class="CodeMirror-code" role="presentation" style=""><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">1</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-operator">&lt;?</span><span class="cm-variable">php</span> </span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">2</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-variable-2">$servername</span> <span class="cm-operator">=</span> <span class="cm-string">"localhost"</span>;</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">3</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-variable-2">$mydb</span> <span class="cm-operator">=</span> <span class="cm-string">"yourdbname"</span>;</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">4</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-variable-2">$username</span> <span class="cm-operator">=</span> <span class="cm-string">"yourusername"</span>;</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">5</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-variable-2">$password</span> <span class="cm-operator">=</span> <span class="cm-string">"yourpassword"</span>;</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">6</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-keyword">try</span></span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">7</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    {</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">8</div></div><pre class=" CodeMirror-line " role="presentation" style="overflow: unset;"><span role="presentation" style="padding-right: 0.1px;">        <span class="cm-variable-2">$conn</span> <span class="cm-operator">=</span> <span class="cm-keyword">new</span> <span class="cm-variable">PDO</span>(<span class="cm-string">"mysql:host=</span><span class="cm-variable-2">$servername</span><span class="cm-string">;dbname=</span><span class="cm-variable-2">$mydb</span><span class="cm-string">"</span>, <span class="cm-variable-2">$username</span>, <span class="cm-variable-2">$password</span>, <span class="cm-variable-2">array(</span><span class="cm-variable">PDO</span>::<span class="cm-variable">MYSQL_ATTR_INIT_COMMAND</span> => <span class="cm-variable">"SET NAMES utf8"</span><span class="cm-variable-2">));</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">9</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">        <span class="cm-variable-2">$conn</span><span class="cm-operator">-&gt;</span><span class="cm-variable">setAttribute</span>(<span class="cm-variable">PDO</span>::<span class="cm-variable">ATTR_ERRMODE</span>, <span class="cm-variable">PDO</span>::<span class="cm-variable">ERRMODE_EXCEPTION</span>);</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">10</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    }</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">11</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    <span class="cm-keyword">catch</span>(<span class="cm-variable">PDOException</span> <span class="cm-variable-2">$e</span>)</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">12</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    {</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">13</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">        <span class="cm-keyword">echo</span> <span class="cm-variable">__error</span>(<span class="cm-string">"connection_problem"</span>, <span class="cm-variable-2">$e</span><span class="cm-operator">-&gt;</span><span class="cm-variable">getMessage</span>());</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">14</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">        <span class="cm-keyword">exit</span>();</span></pre></div><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">15</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">    }</span></pre></div></div></div></div></div></div><div style="position: absolute; height: 60px; width: 1px; border-bottom: 0px solid transparent; top: 278px;"></div><div class="CodeMirror-gutters" style="height: 60px; left: 0px;"></div></div></div>
                        </li>
                        <li>After installation is successfully completed include top of the site <b>poll.php</b></li>
                        <li>Paste the view code where you want it to appear on your site.</li>
                        <li style="list-style:none;margin-top:15px;margin-bottom:15px;">
                            <div class="CodeMirror cm-s-hopscotch" id="c_view"><div class="CodeMirror-scroll" tabindex="-1"><div class="CodeMirror-sizer" style="margin-left: 29px; margin-bottom: -15px; border-right-width: 15px; min-height: 26px; min-width: 382.719px; padding-top: 15px; padding-right: 15px; padding-bottom: 0px;"><div style="position: relative; top: 0px;"><div class="CodeMirror-lines" role="presentation"><div style="text-align:right;"><button class="btn btn-sm btn-dark copy-text2" data-clipboard-target="#c_view" id="showCode">Copy</button></div><div class="CodeMirror-code" role="presentation" style=""><div style="position: relative;"><div class="CodeMirror-gutter-wrapper" style="left: -29px;"><div class="CodeMirror-linenumber CodeMirror-gutter-elt" style="left: 0px; width: 21px;">1</div></div><pre class=" CodeMirror-line " role="presentation"><span role="presentation" style="padding-right: 0.1px;">   <span class="cm-operator">&lt;?</span><span class="cm-variable">php</span> <span class="cm-variable">createPollObject</span>(<span class="cm-string">'theme1'</span>, <span class="cm-string">'your-poll-id'</span>); <span class="cm-operator">?&gt;</span></span></pre></div></div></div></div></div><div style="position: absolute; height: 60px; width: 1px; border-bottom: 0px solid transparent; top: 26px;"></div><div class="CodeMirror-gutters" style="height: 60px; left: 0px;"></div></div></div>
                        </li>
                        <li>You can use 3 theme in your code. <b>theme1</b>, <b>theme2</b>, <b>theme3</b>. Enjoy :)</li>
                    </ul>
                    
                  </div>
                </div>
              </div>
            </div>
            <script src="dist/js/clipboard.min.js"></script>
            <script>
                $(function(){
                  new Clipboard('.copy-text1');
                  new Clipboard('.copy-text2');
                });
            </script>            
            <style>
                .cm-s-hopscotch.CodeMirror {background: #322931; color: #d5d3d5;}
                .cm-s-hopscotch div.CodeMirror-selected {background: #433b42 !important;}
                .cm-s-hopscotch .CodeMirror-gutters {background: #322931; border-right: 0px;}
                .cm-s-hopscotch .CodeMirror-linenumber {color: #797379;float:left;}
                .CodeMirror-lines div {line-height: 1;}
                .cm-s-hopscotch .CodeMirror-cursor {border-left: 1px solid #989498 !important;}
                .CodeMirror-scroll {overflow: auto};
        
                .cm-s-hopscotch span.cm-comment {color: #b33508;}
                .cm-s-hopscotch span.cm-atom {color: #c85e7c;}
                .cm-s-hopscotch span.cm-number {color: #c85e7c;}
                .CodeMirror-code span.cm-operator {color: #d5d3d5;}
                .CodeMirror-line {color: #d5d3d5;} 
                
                .cm-s-hopscotch span.cm-property, .cm-s-hopscotch span.cm-attribute {color: #8fc13e;}
                .cm-s-hopscotch span.cm-keyword {color: #dd464c;}
                .cm-s-hopscotch span.cm-string {color: #fdcc59;}
                
                .cm-s-hopscotch span.cm-variable {color: #8fc13e;}
                .cm-s-hopscotch span.cm-variable-2 {color: #1290bf;}
                .cm-s-hopscotch span.cm-def {color: #fd8b19;}
                .cm-s-hopscotch span.cm-error {background: #dd464c; color: #989498;}
                .cm-s-hopscotch span.cm-bracket {color: #d5d3d5;}
                .cm-s-hopscotch span.cm-tag {color: #dd464c;}
                .cm-s-hopscotch span.cm-link {color: #c85e7c;}
                
                .cm-s-hopscotch .CodeMirror-matchingbracket { text-decoration: underline; color: white !important;}
                .cm-s-hopscotch .CodeMirror-activeline-background { background: #302020; }
                .CodeMirror-gutter-elt {
                  -webkit-touch-callout: none;
                    -webkit-user-select: none;
                     -khtml-user-select: none;
                       -moz-user-select: none;
                        -ms-user-select: none;
                            user-select: none;
                }
                pre{overflow:hidden;}
            </style>
          <?php }elseif($go == 'settings'){ ?>
 

          <div class="row">
              <div class="col-lg-12">
                <div class="card">
                  <div class="card-header">
                    <div class="card-header-title">Settings</div>
                  </div>
                  <div class="card-body">
                    <p>In the voting envisaged only the principle of <b>1ip = 1vote</b>.</p>
                    <p>If you want to skip ip rules you can edit line <b>123</b> in <b>poll.php</b>.</p>
                    <p>Thank you for using our product. This product created special for codecanyon.</p>

                  </div>
                </div>
              </div>
            </div>
          
          
          <?php } ?>
          </div>
        </div>
      </div>
    </div>

    

    <script src="dist/js/vendor.js"></script>
    <script src="dist/js/adminx.js"></script>
    
    
    <script>
        $(document).ready(function(){
          
            $(".deletePoll").click(function(e) {
                e.preventDefault();
                var confirmation = confirm("Your selected poll will be deleted. Are you sure?");
                if (confirmation == true) {
                    
                    var pollIDforDelete = $(this).attr('id');
                    if(pollIDforDelete.length !== 0){
                        $(this).attr('disabled', 'disabled');
                        
                        $.post('admin.php?page=deletePoll', {delete:pollIDforDelete}, function(response){
                            
                            if(response.deleted == 'success'){
                                location.reload(true);
                            }else{
                                alert('Poll deleted failed.');
                            }
                            
                            $(this).removeAttr('disabled');
                        }.bind(this), 'json');                    
                    }
                }
            });
            
            
   
            
            
            
            $(".editPoll").click(function() {
                var poll_id = $(this).parent().siblings('.pollId').html();
                    loadEditForm = $("#editContent");
                    loadEditForm.html("");
                if(poll_id.length > 0){
                    $.post('admin.php?page=getEdit', {editPollId:poll_id}, function(response){
                        if(response.pollExists == 'success'){
                            loadEditForm.html(response.html);
                            loadEditForm.append(response.script);
                        }else{
                            alert('Poll options not found please create new.');
                        }
                    }.bind(this), 'json');                    
                }
                
            });  
            
            
            
            
            $("#addNew").click(function() {
                var question = $("#p_question").val().length;
                var numOptions = $('.newPollOption').length;
                
                if(question !== 0){
                    $(this).attr('disabled', 'disabled');
                    $.post('admin.php?page=addPoll', $('#addNewPoll').serialize(), function(response){
                        if(response.added == 'success'){
                            alert('Thank you, your poll successfully added.');
                            $("#pollModal").modal('hide');
                            location.reload(true);
                        }else{
                            alert('Poll added failed.');
                        }
                        $(this).removeAttr('disabled');
                    }.bind(this), 'json');
                }                
                
            });    
            
            
            
            
            $("#userEditSave").click(function() {
                var confirmation = confirm("Your password and username has been changed. Are you sure? ");
                if (confirmation == true) {
                    var passField = $("#userInputPassword").val().length;
                    if(passField !== 0){
                        $(this).attr('disabled', 'disabled');
                        $.post('admin.php?page=changePassword', $('#changePassword').serialize(), function(response){
                            if(response.password == 'success'){
                                alert('Your password has been changed. Please login again.');
                                $("#userModal").modal('hide');
                                location.reload(true);
                            }else{
                                alert('Your password has not been changed');
                            }
                            $(this).removeAttr('disabled');
                        }.bind(this), 'json');
                    }                   
                }
            });
            
            
            

            
            

          
        });
    </script>
  </body>
</html>

<?php
}else{
?>

<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Script installation">
    <title>Login page</title>
    <link rel="icon" href="images/favicon.ico">
    <link href="admin/css/bootstrap.min.css" rel="stylesheet">
    <style>
        *{
            padding:0;
            margin:0;
            list-style:none;
            border:0;
            outline:0;
            box-sizing:border-box;
        }
        html,body{
            height:100%;
        }
        body{
            display:flex;
            align-items:center;
            justify-content:center;
            background-color:#f4f4f4!important;
        }
        .container {
            width: auto;
            max-width: 680px;
            padding: 0 15px;
        }
        form{
            border:1px solid #ddd;
            width:400px;
            padding:20px;
            background:#fff;
        }
        form>ul{
            padding-left:0px;
            margin-bottom:0px!important;
        }        
        form>ul>li{
            margin-bottom:20px;
        }
        form>ul>li:last-child{
            margin-bottom:0px;
        }       
        form>ul>li input{
            background:#eee;
            height:40px;
            padding:0 15px;
            border-radius:3px;
            width:100%;
        }        
        form>ul>li button{
            height:40px;
            padding:0 30px;
            color:#fff;
            background:orange;
            outline:none!important;
            outline-style: none!important;
            border:none;
        }
        [disabled]{
            opacity:.8;
            position:relative;
            overflow:hidden;
        }
        [disabled]:before{
            content: '';
            height:4px;
            background: rgba(0, 0, 0, .2);
            position:absolute;
            top:0;
            left:0;
            right:0;
            animation: loading 5s infinite;
        }
        @keyframes loading {
            from {transform: translateX(-100%);}
            to {transform: translateX(100%);}
        }
        .logo{
            width:100px;
            margin-bottom:20px;
        }
        .attempt{color:#F00;display:none;}
        .wrap {
          text-align:center;
          display: inline-block;
          height: 100px;
          width: 100px;
          position: relative;
          overflow: hidden;
        }
        .wrap img {
          text-align:center;
          position: absolute;
          top: 0;
          left: 0;
          width: 100px;
        }
        .wrap:before {
          content: "";
          z-index: 10;
          position: absolute;
          height: 200%;
          width: 200%;
          top: -120%;
          left: -120%;
          background: linear-gradient(transparent 0%, rgba(255, 255, 255, 0.1) 45%, rgba(255, 255, 255, 0.5) 50%, rgba(255, 255, 255, 0.1) 55%, transparent 100%);
          transition: all 2s;
          transform: rotate(-45deg);
          animation: shine 6s infinite forwards;
        }
        @keyframes shine {
          0% {
            top: -120%;
            left: -120%;
          }
          20% {
            left: 100%;
            top: 100%;
          }
          40% {
            left: 100%;
            top: 100%;
          }
          100% {
            left: 100%;
            top: 100%;
          }
        }        
    </style>
  </head>
  <body>
      
      <main class="container">
      <div style="text-align:center;"><div class="wrap"><img src="images/logo.png" class="logo"></div></div>
      <form id="form">
            <ul>
                <li><input type="text" name="uname" placeholder="Username" autocomplete="off"></li>
                <li><input type="password" name="passwd" placeholder="Password" autocomplete="off"></li>
                <li><button class="submit-btn" type="submit">Login</button> <span class="attempt">Wrong user details!</span></li>
            </ul>
      </form>      
      </main>
      
      <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
      <script>
          $('.submit-btn').on('click', function(){
              $(this).attr('disabled', 'disabled');
              $.post('admin.php', $('#form').serialize(), function(response){
                    if(response.user == 'success'){
                        location.reload(true);
                    }else{
                        $('.attempt').css('display','inline-block');
                    }
                    $(this).removeAttr('disabled');
              }.bind(this), 'json');
          });
      </script>
  </body>
</html>

<?php
}
?>