<!doctype html>
<html lang="en" class="h-100">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Script installation">
    <title>Installation</title>
    <link href="app/install/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <style>
        body{
            background-color:#f4f4f4!important;
        }
        .container {
            width: auto;
            max-width: 680px;
            padding: 0 15px;
        }
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }
        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
            font-size: 3.5rem;
            }
        }
    </style>
  </head>
  <body>
    
        <main class="container">
            <div class="my-3 p-3 bg-white rounded shadow-sm">
                <?php
                /*
                * Installation PHP file
                */
                
                function miniFilter($variable = null){
                    $var = preg_replace("/[^a-zA-Z0-9_@-]+/", "", $variable);
                    return $var;                    
                }
                
                
                if (file_exists('app/mysql.php')) {
                    echo '<h2>The installation has already been done.</h2>
                        <p class="lead">
                            <ul>
                                <li>Please, delete <b>install.php</b>.</li>
                                <li>If you want to re-install <u>PHP, jQuery & Bootstrap Poll Script</u> please manually delete <b>app/mysql.php</b> file first, then refresh this page.</li>
                            </ul>
                        </p>
                            <a href="app/admin.php" class="btn btn-success"><span class="text">Go to Admin</span></a>
                            <a href="index.php" class="btn btn-primary"><span class="text">Go to Poll</span></a>';
                }else{
                    switch(@$_GET['step']){
                        
                        case 2:
                            
                            if(!empty($_POST['db_host']) && 
                                !empty($_POST['db_name']) && 
                                !empty($_POST['db_username']) && 
                                !empty($_POST['db_password']) && 
                                !empty($_POST['adm_uname']) && 
                                !empty($_POST['adm_passwd']) && 
                                parse_url($_SERVER['HTTP_REFERER'], PHP_URL_QUERY) == 'step=1'){
                            
                                if(file_exists('app/mysql.php')!= FALSE){
                                    echo '<p class="lead">You have already created a database file.
                                                <ul>
                                                    <li>If you want to recreate, you must manually delete the <b>mysql.php</b> file under the <b>app</b> folder.</li>
                                                    <li>If you have already deleted the file, click the Refresh page button.</li>
                                                </ul>
                                            </p>
                                        <a href="?step=2" class="btn btn-primary"><span class="text">Refresh page</span></a>
                                        <a href="app/admin.php" class="btn btn-success"><span class="text">Go to Admin</span></a>
                                        <a href="index.php" class="btn btn-primary"><span class="text">Go to Poll</span></a>';
                                }else{
                                    
                                    $mysql_php = 'app/mysql.php';
                                    $mysql_code = '<?php $servername="'.miniFilter($_POST['db_host']).'";$mydb="'.miniFilter($_POST['db_name']).'";$username="'.miniFilter($_POST['db_username']).'";$password="'.miniFilter($_POST['db_password']).'";try{$conn=new PDO("mysql:host=$servername;dbname=$mydb",$username,$password,array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);}catch(PDOException $e){echo __error("connection_problem",$e->getMessage());exit();}';
    
                                    if (file_put_contents($mysql_php, $mysql_code) !== false){
                                        require_once($mysql_php);
                                        $uname = miniFilter($_POST['adm_uname']);
                                        $passwd = md5(md5(miniFilter($_POST['adm_passwd'])));
                                        $scriptPath = __DIR__;
                                        $sql_import = "CREATE TABLE `poll_answers`( `id` int(11) NOT NULL, `question_id` int(11) DEFAULT NULL, `answer` varchar(255) DEFAULT NULL, `show_status` int(11) DEFAULT 1) ENGINE=MyISAM DEFAULT CHARSET=utf8; CREATE TABLE `poll_configs` ( `id` int(11) NOT NULL, `config_settings` text NOT NULL ) ENGINE=MyISAM DEFAULT CHARSET=utf8; CREATE TABLE `poll_questions` ( `id` int(11) NOT NULL, `question` text DEFAULT NULL, `created_at` varchar(255) DEFAULT NULL, `updated_at` varchar(255) DEFAULT NULL, `show_status` int(1) NOT NULL DEFAULT 1 ) ENGINE=MyISAM DEFAULT CHARSET=utf8; CREATE TABLE `poll_tracking` ( `id` int(11) NOT NULL, `question_id` int(11) DEFAULT NULL, `answer_id` int(11) DEFAULT NULL, `user_ip` varchar(255) DEFAULT NULL, `user_agent` varchar(255) DEFAULT NULL, `created_at` varchar(255) DEFAULT NULL ) ENGINE=MyISAM DEFAULT CHARSET=utf8; ALTER TABLE `poll_answers` ADD PRIMARY KEY (`id`); ALTER TABLE `poll_configs` ADD PRIMARY KEY (`id`); ALTER TABLE `poll_questions` ADD PRIMARY KEY (`id`); ALTER TABLE `poll_tracking` ADD PRIMARY KEY (`id`); ALTER TABLE `poll_answers` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1; ALTER TABLE `poll_configs` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1; ALTER TABLE `poll_questions` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1; ALTER TABLE `poll_tracking` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1; COMMIT; INSERT INTO `poll_answers`(`id`, `question_id`, `answer`, `show_status`) VALUES (1, 1, 'PHP', 1), (2, 1, 'Python', 1), (3, 1, 'C#', 1), (4, 1, 'Java', 1), (5, 2, 'Purple', 1), (6, 2, 'Yellow', 1), (7, 2, 'Orange', 1), (8, 2, 'Red', 1), (9, 3, '5.000$', 1), (10, 3, '10.000$', 1), (11, 3, '15.000$', 1), (12, 3, '20.000$', 1); INSERT INTO `poll_questions` (`id`, `question`, `created_at`, `updated_at`, `show_status`) VALUES (1, 'What\'s your favorite language?\r\n', '1610312598', '1610312613', 1), (2, 'What\'s your favorite color?', '1610317701', '1610317801', 1), (3, 'How much of your monthly salary?', '1610317742', '1610317842', 1); INSERT INTO `poll_tracking` (`id`, `question_id`, `answer_id`, `user_ip`, `user_agent`, `created_at`) VALUES (1, 1, 4, '185.81.82.180', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610481576'), (2, 1, 1, '185.81.82.181', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610481591'), (3, 1, 2, '185.81.82.182', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610481606'), (4, 1, 3, '185.81.82.183', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610484340'), (5, 1, 1, '185.81.82.184', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610484364'), (6, 1, 2, '185.81.82.186', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610484393'), (7, 1, 1, '185.81.82.187', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610485132'), (8, 1, 1, '185.81.82.188', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610486011'), (9, 1, 2, '185.81.82.189', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610486114'), (13, 1, 2, '185.81.82.190', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610486969'), (12, 1, 13, '185.81.82.191', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610486532'), (17, 1, 4, '185.81.82.192', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610835092'), (18, 2, 5, '185.81.82.193', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610835103'), (19, 3, 9, '185.81.82.194', 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.111 Safari/537.36', '1610835119'); INSERT INTO `poll_configs` (`id`, `config_settings`) VALUES (1, '{\r\n\"install\": \"yes\",\r\n\"path\": \"".$scriptPath."\",\r\n\"poll_id\": {\r\n \"0\": \"1\",\r\n \"1\": \"2\",\r\n \"2\": \"3\"\r\n},\r\n\"selected_theme\": {\r\n \"0\": \"theme1\",\r\n \"1\": \"theme2\",\r\n \"2\": \"theme3\"\r\n},\r\n\"theme1\": {\r\n \"theme_name\": \"Blue theme\",\r\n \"swatch\": \"blue\",\r\n \"btn\": \"btn btn-primary\",\r\n \"theme_code\": \"theme1\"\r\n},\r\n\"theme2\": {\r\n \"theme_name\": \"Indigo theme\",\r\n \"swatch\": \"indigo\",\r\n \"btn\": \"btn btn-custom2\",\r\n \"theme_code\": \"theme2\"\r\n},\r\n\"theme3\": {\r\n \"theme_name\": \"Purple theme\",\r\n \"swatch\": \"purple\",\r\n \"btn\": \"btn btn-custom3\",\r\n \"theme_code\": \"theme3\"\r\n},\r\n\"title\": \"Polling <span class=nano>system</span>\",\r\n\"adm_uname\": \"".$uname."\",\r\n\"adm_passwd\": \"".$passwd."\"\r\n}');";
                                        $stmt = $conn->prepare($sql_import);
                                        if($stmt->execute()){
                                            
                                            echo '<h1>Installation done.</h1>
                                                <p class="lead">
                                                    <ul>
                                                        <li>Thank you for install our product.</li>
                                                        <li>Please, delete <b>install.php</b>.</li>
                                                        <li>If you want to re-install <u>PHP, jQuery & Bootstrap Poll Script</u> please manually delete <b>app/mysql.php</b> file first, then refresh this page.</li>
                                                    </ul>
                                                </p>
                                                    <a href="app/admin.php" class="btn btn-success"><span class="text">Go to Admin</span></a>
                                                    <a href="index.php" class="btn btn-primary"><span class="text">Go to Poll</span></a>';
                                        }
                                        
                                    } else {
                                        echo "Cannot create file (".basename($mysql_php).")";
                                    }
                                }
                            }else{
                                header('location: ?step=0');
                            }
                            break;
                        case 1:
                            echo '<p class="lead">Enter your database connection details. If you\'re not sure about these, contact your host.</p>';
                            echo '<form method="post" action="?step=2"><div class="row">
                                    <div class="col-sm-3">
                                      <p>Database name</p>
                                    </div>
                                    <div class="col-sm-4">
                                      <p><input type="text" name="db_name"></p>
                                    </div>
                                    <div class="col-sm-5">
                                      <p>The name of the database.</p>
                                    </div>
                                    <div class="col-sm-3">
                                      <p>Username</p>
                                    </div>
                                    <div class="col-sm-4">
                                      <p><input type="text" name="db_username"></p>
                                    </div>
                                    <div class="col-sm-5">
                                      <p>Your database username.</p>
                                    </div>
                                    <div class="col-sm-3">
                                      <p>Password</p>
                                    </div>
                                    <div class="col-sm-4">
                                      <p><input type="password" name="db_password"></p>
                                    </div>
                                    <div class="col-sm-5">
                                      <p>Your database password.</p>
                                    </div>
                                    <div class="col-sm-3">
                                      <p>Database host</p>
                                    </div>
                                    <div class="col-sm-4">
                                      <p><input type="text" name="db_host" value="localhost"></p>
                                    </div>
                                    <div class="col-sm-5">
                                      <p>As usual is <b>localhost.</b></p>
                                    </div>
                                  </div>
                                  
                                  <p class="lead">Create polling admin account.</p>';
                            echo '<div class="row">
                                    <div class="col-sm-3">
                                      <p>Username</p>
                                    </div>
                                    <div class="col-sm-4">
                                      <p><input type="text" name="adm_uname"></p>
                                    </div>
                                    <div class="col-sm-5">
                                      <p>Admin login name.</p>
                                    </div>
                                    <div class="col-sm-3">
                                      <p>Password</p>
                                    </div>
                                    <div class="col-sm-4">
                                      <p><input type="password" name="adm_passwd"></p>
                                    </div>
                                    <div class="col-sm-5">
                                      <p>Admin login pasword.</p>
                                    </div>
                                </div>';
                                
                            echo '<button class="btn btn-primary" type="submit"><span class="text">Save and continue</span></button></form>';

                            break;
                        
                        default:
                               echo '<p class="lead"><center>Welcome to <u><b>PHP, jQuery & Bootstrap Poll Script</b></u>.</center> <br />Before getting started, we need some information on the database.
                                    <ul>
                                        <li>Database name</li>
                                        <li>Database username</li>
                                        <li>Database password</li>
                                        <li>Database host</li>
                                    </ul>
                                    We\'re going to use this information to create <b>mysql.php</b> file. <br />
                                    If you don\'t have this information, then you will need to contact them before you can continue. If you\'re all ready..
                               </p>';
                               echo '<a href="?step=1" class="btn btn-primary"><span class="text">Let\'s go</span></a>';

                    }

                    
                }
                ?>
            </div>
        </main>


  </body>
</html>
